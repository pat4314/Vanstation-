
function calculateTotalPrice() {
  let carPrice = parseFloat(document.getElementById('carPrice').value) || 0;
  let driverAccommodation = parseFloat(document.getElementById('driverAccommodation').value) || 0;
  let totalPrice = carPrice + driverAccommodation;
  let deposit = parseFloat(document.getElementById('deposit').value) || 0;
  let remaining = totalPrice - deposit;

  document.getElementById('totalPrice').value = totalPrice;
  document.getElementById('remaining').value = remaining;
}

document.getElementById('bookingForm').addEventListener('submit', function(event) {
  event.preventDefault();
  calculateTotalPrice();

  let bookingNumber = document.getElementById('bookingNumber').value;
  let customerName = document.getElementById('customerName').value;
  let phone = document.getElementById('phone').value;
  let passengers = document.getElementById('passengers').value;
  let carType = document.getElementById('carType').value;
  let tripType = document.getElementById('tripType').value;
  let travelDate = document.getElementById('travelDate').value;
  let travelTime = document.getElementById('travelTime').value;
  let pickupLocation = document.getElementById('pickupLocation').value;
  let destination = document.getElementById('destination').value;

  document.getElementById('bookingModal').classList.remove('hidden');
  document.getElementById('bookingReceipt').innerHTML = `
    <h3>ใบจองเลขที่ ${bookingNumber}</h3>
    <p>ชื่อผู้จอง: ${customerName}</p>
    <p>เบอร์โทรศัพท์: ${phone}</p>
    <p>จำนวนผู้โดยสาร: ${passengers} ท่าน</p>
    <p>ประเภทรถ: ${carType}</p>
    <p>ประเภทการเดินทาง: ${tripType}</p>
    <p>วันที่เดินทาง: ${travelDate}</p>
    <p>เวลานัดหมาย: ${travelTime}</p>
    <p>จุดรับ: ${pickupLocation}</p>
    <p>ปลายทาง: ${destination}</p>
    <p>ราคารวมทั้งหมด: ฿ ${document.getElementById('totalPrice').value}</p>
    <p>มัดจำ: ฿ ${document.getElementById('deposit').value}</p>
    <p>คงเหลือ: ฿ ${document.getElementById('remaining').value}</p>
  `;
});

document.getElementById('closeModal').addEventListener('click', function() {
  document.getElementById('bookingModal').classList.add('hidden');
});
